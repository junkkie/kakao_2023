import React from 'react'
import { Link } from 'react-router-dom'
import '../styles/Tab.scss'

function Tab() {
  return (
    <nav class="tab_bar">
      <ul>
      <li><Link to='/'>Friends</Link></li>
      <li><Link to='/chats'>Chats</Link></li>
      <li><Link to='/find'>Find</Link></li>
      <li><Link to='/more'>More</Link></li>
      </ul> 
    </nav>
  )
}

export default Tab